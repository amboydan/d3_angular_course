import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-chart1',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './chart1.component.html',
  styleUrl: './chart1.component.scss'
})
export class Chart1Component {

  data = [125, 120, 70, 75, 160];
  width = 50;
  //creating a column chart

}
